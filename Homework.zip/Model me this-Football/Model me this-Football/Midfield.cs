﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model_me_this_Football
{
    public class Midfield
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public int Age { get; set; }
        public int Height { get; set; }
    }
}

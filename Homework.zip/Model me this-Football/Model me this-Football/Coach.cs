﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model_me_this_Football
{
   public class Coach
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
